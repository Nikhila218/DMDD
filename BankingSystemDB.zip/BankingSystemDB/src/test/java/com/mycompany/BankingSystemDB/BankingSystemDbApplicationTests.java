package com.mycompany.BankingSystemDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSystemDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
